<?php

define('baseurl','http://localhost/jiln/public');